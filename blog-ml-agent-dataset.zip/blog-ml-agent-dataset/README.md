# 装配质量场景完整示例数据

本数据包为《面向装配质量管理的 AI Agent 方案实践》配套材料。数据由本文的随机模拟程序生成，不是从公开工业数据集下载，也不包含客户生产记录。随包提供本次实际使用的完整文件，无需AWS账号即可读取CSV。

## 数据范围

模拟100个生产日、8240台发动机。8000台有首次有效测试标签；200台只有无效测试，40台结果未知。标签first_eol_fail中1表示首次有效测试失败，0表示通过。首次失败后复测通过不覆盖原标签。记录中的时间、工艺数值、类别与失败关系均为模拟设定。

| 文件 | 内容 |
|---|---|
| data/assembly-source.csv | 全部8240台对象的装配及工序记录 |
| data/eol-events.csv | 下线测试事件，包括无效测试和返修后复测 |
| data/label-ledger.csv | 装配记录与首次有效结果的关联台账 |
| data/train.csv | 前60日4800条有标签训练样本 |
| data/validation.csv | 随后20日1600条有标签验证样本 |
| data/test.csv | 最后20日1600条有标签保留测试样本 |
| data/*-features.csv | 对应数据的纯特征输入，不含标签 |
| data/*-index.csv | 与特征逐行对应的对象、时间、日序号和标签 |
| data/validation-arrivals-*.csv | 验证期完整1660次到达，含60条未知结果 |
| data/test-arrivals-*.csv | 测试期完整1660次到达，含60条未知结果 |
| data/online.csv 与 online-index.csv | 测试集中预先固定的前40条，用于在线一致性检查 |
| data/invalid-schema.csv | 两条刻意缺少扭矩字段的异常输入，不用于训练 |
| results/*predictions.csv | 实际保留的模型预测文件，含prob_1等输出 |
| results/test-review-decisions.csv | 按冻结阈值、到达顺序和每日名额产生的复核记录 |
| results/frozen-policy.json | 仅使用验证期确定的模型及扭矩规则阈值 |
| results/*business-metrics.json | 验证及测试的完整策略统计 |
| data-dictionary.csv | 特征、标签及关联字段说明 |

test.csv用于有标签模型评价；test-arrivals-features.csv连同test-arrivals-index.csv用于完整业务队列回放。两者用途不同，未知结果对象在复核中照常占用名额，统计时单独列出。特征CSV和对应index按行一一匹配，不应各自独立排序。

## 生成与核对

随机种子为20260928。生成脚本在scripts目录，依赖Python 3.11或更高版本、NumPy与pandas。dataset.py生成基础数据，prepare_arrivals.py补齐包含未知对象的到达队列。已随包提供冻结CSV，通常不必重新生成。data/dataset-manifest.json保留所有19个输入文件的SHA-256，均与实际实验输入逐字节一致。

若需要单独重建数据，请将scripts目录复制到一个新的空目录，在该副本中依次运行dataset.py和prepare_arrivals.py。不要覆盖本数据包或将新模型输出混入冻结输入。CSV文本序列化会受Python及依赖版本影响，原实验复核应以随包文件和哈希为准。

运行scripts/verify_package.py可以在本地核对全包文件哈希，无需第三方依赖、网络或AWS凭据。复算已保存的业务策略使用scripts/replay_policy.py，读取已有预测，不重训模型、不访问云端。

## 结果含义

在保留测试期，模型策略复核146台并覆盖22台已知首次失败；扭矩规则复核143台，同样覆盖22台。两者均遗漏61台已知失败。模型所选对象中另有3台结果未知。按模型每天实际名额随机选择的理论期望为约7.47台已知失败。由此可以看到风险集中现象，但不能得出多变量模型优于扭矩规则或真实工厂质量已经改善的结论。

模型训练、评估、离线与临时在线预测及资源回收已贯通；40条预先固定样本的离线/在线分类结果一致。它们支持技术链路的可执行性，不等价于长期SLA、工厂收益或已批准的生产发布。

生成器中扭矩偏差具有较强的标签关联，因此简单扭矩规则是必要对照。请勿修改保留测试标签、筛选有利样本或反复调参后继续把同一数据称作未见测试集。
