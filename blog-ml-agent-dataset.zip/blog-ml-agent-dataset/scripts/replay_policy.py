"""Recompute frozen arrival policies from the supplied saved predictions."""
import csv, json, math
from pathlib import Path
root = Path(__file__).resolve().parent.parent
def rows(name):
    with (root / name).open(newline="") as f: return list(csv.DictReader(f))
index = rows("data/test-arrivals-index.csv")
features = rows("data/test-arrivals-features.csv")
predictions = rows("results/test-arrivals-predictions.csv")
assert len(index) == len(features) == len(predictions) == 1660
policy = json.loads((root / "results/frozen-policy.json").read_text())
for name in ("model", "torque_only"):
    rule = policy["rules"][name]
    used, selected, captured, passed, unknown, expected = {}, 0, 0, 0, 0, 0.0
    by_day = {}
    for meta in index:
        day = int(meta["production_day"]); known = meta["first_eol_fail"]
        day_stats = by_day.setdefault(day, [0, 0]); day_stats[0] += 1
        if known and float(known) == 1: day_stats[1] += 1
    for meta, feature, prediction in zip(index, features, predictions):
        day = int(meta["production_day"])
        score = float(prediction["prob_1"] if name == "model" else feature["torque_deviation_pct"])
        if score < rule["threshold"] or used.get(day, 0) >= rule["daily_cap"]: continue
        used[day] = used.get(day, 0) + 1; selected += 1
        outcome = meta["first_eol_fail"]
        if not outcome: unknown += 1
        elif float(outcome) == 1: captured += 1
        else: passed += 1
    expected = sum(count * by_day[day][1] / by_day[day][0] for day, count in used.items())
    actual = {"reviewed": selected, "captured_failures": captured, "reviewed_passes": passed,
              "reviewed_unknown": unknown, "random_expected_captured_same_daily_review_counts": expected}
    recorded = json.loads((root / "results/business-metrics.json").read_text())["policies"][name]
    for key, value in actual.items(): assert math.isclose(value, recorded[key], rel_tol=1e-10), (name, key)
    print(name, json.dumps(actual, ensure_ascii=False))
