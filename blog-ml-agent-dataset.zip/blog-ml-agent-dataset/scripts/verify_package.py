"""Verify the delivered file set locally with Python standard library."""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent.parent
manifest = json.loads((root / "package-manifest.json").read_text())
for name, expected in manifest["files"].items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    assert actual == expected["sha256"], name
print(f"Verified {len(manifest['files'])} files; no network calls.")
