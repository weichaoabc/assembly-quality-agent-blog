"""Synthetic EOL first-valid-test risk: reproducible data, not customer records."""
import hashlib
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent.parent / 'data'
BASE.mkdir(exist_ok=True)
SEED = 20260928
LABEL = "first_eol_fail"
FEATURES = [
    "torque_deviation_pct", "angle_deviation_deg", "tightening_retries",
    "cycle_time_sec", "station_wait_min", "tool_cycles_since_service",
    "vibration_rms", "ambient_temp_c", "ambient_humidity_pct",
    "fixture_id", "component_variant", "shift",
    "upstream_microstops_60m", "pressure_stability_kpa",
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build():
    if (BASE / "dataset-manifest.json").exists():
        manifest = json.loads((BASE / "dataset-manifest.json").read_text())
        for name, info in manifest["files"].items():
            assert digest(BASE / name) == info["sha256"], name
        print("Existing immutable synthetic dataset verified; not regenerated.")
        return
    rng = np.random.default_rng(SEED)
    assembly, events = [], []
    start = datetime(2026, 4, 1, tzinfo=UTC)
    for day in range(100):
        # 80 eligible objects, two with no valid outcome, and 40 late pending
        # objects in total. Non-eligible objects never become negative labels.
        count = 82 + int(day >= 60)
        for ordinal in range(count):
            number = len(assembly) + 1
            engine = f"SIM-E-{number:06d}"
            cutoff = start + timedelta(days=day, hours=6, minutes=6 * ordinal)
            drift = max(day - 55, 0) / 45
            wear = rng.uniform(0, 1)
            deviation = max(0, rng.gamma(1.7, 0.85) + 0.30 * drift)
            angle = max(0, rng.gamma(1.5, 1.4) + 0.25 * deviation)
            retries = int(rng.poisson(0.25 + 0.16 * deviation + 0.2 * wear))
            vibration = max(0.1, rng.normal(1.2 + 0.7 * wear, 0.35))
            pressure = max(0.05, rng.gamma(1.8, 0.8))
            fixture = rng.choice(["F1", "F2", "F3", "F4"])
            if day >= 70 and rng.random() < 0.16:
                fixture = "F5"
            component = rng.choice(["A", "B", "C"], p=[0.5, 0.3, 0.2])
            microstops = int(rng.poisson(1.1 + 0.25 * drift))
            cycle = max(60, rng.normal(112 + 4 * retries + 2 * microstops, 12))
            waiting = max(0, rng.gamma(1.6, 2.0) + microstops * 0.5)
            # A stochastic simulator, deliberately incomplete and non-causal.
            # No real process tolerances or a real factory quality rates are encoded.
            logit = (
                -5.9 + 0.76 * deviation + 0.32 * retries
                + 0.29 * pressure + 0.35 * (vibration - 1)
                + 0.52 * (component == "C") + 0.36 * (fixture in {"F4", "F5"})
                + 0.26 * drift + 0.34 * (deviation > 2.5 and retries >= 2)
                + rng.normal(0, 0.55)
            )
            failed = int(rng.random() < 1 / (1 + np.exp(-logit)))
            values = {
                "torque_deviation_pct": round(deviation, 4),
                "angle_deviation_deg": round(angle, 4),
                "tightening_retries": retries,
                "cycle_time_sec": round(cycle, 3),
                "station_wait_min": round(waiting, 3),
                "tool_cycles_since_service": int(wear * 15000),
                "vibration_rms": round(vibration, 4),
                "ambient_temp_c": round(rng.normal(23 + 1.5 * drift, 2.0), 3),
                "ambient_humidity_pct": round(rng.uniform(30, 65), 3),
                "fixture_id": fixture, "component_variant": component,
                "shift": "A" if ordinal < 40 else "B",
                "upstream_microstops_60m": microstops,
                "pressure_stability_kpa": round(pressure, 4),
            }
            for field, probability in [
                ("vibration_rms", 0.035 + 0.025 * drift),
                ("angle_deviation_deg", 0.025),
                ("ambient_humidity_pct", 0.015),
            ]:
                if rng.random() < probability:
                    values[field] = np.nan
            assembly.append({
                "engine_id": engine, "production_day": day + 1,
                "assembly_completed_at": cutoff.isoformat(),
                "latest_feature_recorded_at": (cutoff - timedelta(seconds=5)).isoformat(),
                "engine_family": "SIM-FAMILY-A", "line_id": "SIM-LINE-1",
                **values,
            })
            if ordinal == 82:  # Not observed yet; outcome unknown.
                continue
            test_at = cutoff + timedelta(minutes=25)
            if ordinal >= 80 or rng.random() < 0.025:
                events.append({
                    "engine_id": engine, "event_id": f"{engine}-invalid",
                    "tested_at": test_at.isoformat(), "valid": False,
                    "outcome": "INVALID", "eol_measurement": np.nan,
                    "post_test_repair_code": "",
                })
                test_at += timedelta(minutes=8)
            if ordinal >= 80:
                continue
            events.append({
                "engine_id": engine, "event_id": f"{engine}-valid-1",
                "tested_at": test_at.isoformat(), "valid": True,
                "outcome": "FAIL" if failed else "PASS",
                "eol_measurement": round(rng.normal(3.0 if failed else 0, 1), 3),
                "post_test_repair_code": "SIM-REVIEW" if failed else "",
            })
            if failed:
                events.append({
                    "engine_id": engine, "event_id": f"{engine}-valid-2",
                    "tested_at": (test_at + timedelta(hours=2)).isoformat(),
                    "valid": True, "outcome": "PASS",
                    "eol_measurement": round(rng.normal(0, 1), 3),
                    "post_test_repair_code": "SIM-RETEST",
                })
    source = pd.DataFrame(assembly)
    event_frame = pd.DataFrame(events)
    valid = event_frame[event_frame["valid"]].sort_values(["engine_id", "tested_at"])
    first = valid.drop_duplicates("engine_id", keep="first")
    labels = first[["engine_id", "tested_at", "outcome"]].copy()
    labels[LABEL] = (labels["outcome"] == "FAIL").astype(int)
    joined = source.merge(labels, on="engine_id", how="left", validate="one_to_one")
    eligible = joined.dropna(subset=[LABEL]).copy()
    eligible[LABEL] = eligible[LABEL].astype(int)
    assert len(eligible) == 8000
    assert eligible["engine_id"].is_unique
    assert (eligible["latest_feature_recorded_at"] <= eligible["assembly_completed_at"]).all()
    assert (eligible["assembly_completed_at"] < eligible["tested_at"]).all()
    assert eligible.groupby("production_day").size().eq(80).all()
    subsets = {
        "train": eligible[eligible.production_day <= 60],
        "validation": eligible[eligible.production_day.between(61, 80)],
        "test": eligible[eligible.production_day > 80],
    }
    source.to_csv(BASE / "assembly-source.csv", index=False)
    event_frame.to_csv(BASE / "eol-events.csv", index=False)
    joined.to_csv(BASE / "label-ledger.csv", index=False)
    metadata = ["engine_id", "production_day", "assembly_completed_at", LABEL]
    details = {}
    seen = set()
    for role, frame in subsets.items():
        ids = set(frame.engine_id)
        assert not ids & seen
        seen |= ids
        frame[FEATURES + [LABEL]].to_csv(BASE / f"{role}.csv", index=False)
        frame[FEATURES].to_csv(BASE / f"{role}-features.csv", index=False)
        frame[metadata].to_csv(BASE / f"{role}-index.csv", index=False)
        details[role] = {
            "rows": len(frame), "failures": int(frame[LABEL].sum()),
            "failure_rate": float(frame[LABEL].mean()),
            "first_cutoff": frame.assembly_completed_at.min(),
            "last_cutoff": frame.assembly_completed_at.max(),
            "missing_by_column": frame[FEATURES].isna().sum().to_dict(),
        }
    assert details["train"]["last_cutoff"] < details["validation"]["first_cutoff"]
    assert details["validation"]["last_cutoff"] < details["test"]["first_cutoff"]
    # Deliberate fixed first-40 sample, not chosen for desirable predictions.
    online = subsets["test"].iloc[:40]
    online[FEATURES].to_csv(BASE / "online.csv", index=False)
    online[metadata].to_csv(BASE / "online-index.csv", index=False)
    subsets["validation"][FEATURES].drop(columns=["torque_deviation_pct"]).head(2).to_csv(
        BASE / "invalid-schema.csv", index=False
    )
    files = {}
    for path in sorted(BASE.glob("*.csv")):
        files[path.name] = {"sha256": digest(path), "bytes": path.stat().st_size}
    manifest = {
        "dataset_version": 1, "source": "SYNTHETIC; NOT CUSTOMER PRODUCTION DATA",
        "seed": SEED, "generator_sha256": digest(Path(__file__)),
        "created_at": datetime.now(UTC).isoformat(),
        "scenario": "Risk of first VALID engine EOL test failure, at assembly completion",
        "source_rows": len(source), "eligible_rows": len(eligible),
        "invalid_only_excluded": 200, "pending_outcome_excluded": 40,
        "retreatments_do_not_overwrite_first_valid_label": True,
        "label": LABEL, "positive_class": 1, "features": FEATURES,
        "excluded_from_features": [
            "engine_id", "production_day", "assembly_completed_at",
            "latest_feature_recorded_at", "tested_at", "outcome",
            "eol_measurement", "post_test_repair_code", "valid",
        ],
        "split": details, "entity_intersection_rows": 0,
        "feature_cutoff_violations": 0,
        "split_verification_scope": "Verified against synthetic ledger; not a customer data audit",
        "policy_preregistered": {
            "capacity_fraction": 0.10, "engines_per_simulated_day": 80,
            "daily_review_cap": 8,
            "threshold_selection": "90th percentile of validation failure scores, never test scores",
            "execution": "Chronological arrivals: review if score >= frozen threshold and daily quota remains",
            "no_future_scores_used": True,
            "ranking_top_10_percent": "Retrospective diagnostic only; not the executable arrival policy",
            "business_action": "Quality engineer extra review; no EOL replacement or automatic release",
        },
        "simulation_limits": [
            "Process values, availability, prevalence, drift and effects are invented.",
            "Ranking model learns a simulator; no claim of a real factory predictive performance.",
            "No causal or intervention benefit is established.",
            "The streaming quota assumes known 80-engine daily eligible volume.",
        ],
        "files": files,
    }
    (BASE / "dataset-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"rows": len(eligible), "excluded": len(source) - len(eligible),
                      "splits": details}, ensure_ascii=False))


if __name__ == "__main__":
    build()
