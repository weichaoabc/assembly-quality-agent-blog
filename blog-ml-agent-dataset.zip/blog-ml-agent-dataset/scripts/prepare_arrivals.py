"""Keep unlabelled engines in the operational queue, outside supervised fitting."""
import json
from pathlib import Path
import pandas as pd
from dataset import BASE, FEATURES, LABEL, digest

manifest = json.loads((BASE / "dataset-manifest.json").read_text())
assert not (BASE / "state.json").exists(), "Do not change a dataset already submitted to AWS."
ledger = pd.read_csv(BASE / "label-ledger.csv")
for role, first, last in [("validation", 61, 80), ("test", 81, 100)]:
    frame = ledger[ledger.production_day.between(first, last)].copy()
    assert len(frame) == 1660 and frame[LABEL].notna().sum() == 1600
    names = [f"{role}-arrivals-features.csv", f"{role}-arrivals-index.csv"]
    frame[FEATURES].to_csv(BASE / names[0], index=False)
    frame[["engine_id", "production_day", "assembly_completed_at", LABEL]].to_csv(BASE / names[1], index=False)
    for name in names:
        manifest["files"][name] = {"sha256": digest(BASE / name), "bytes": (BASE / name).stat().st_size}
    manifest["split"][role]["operational_arrivals"] = len(frame)
    manifest["split"][role]["outcome_unknown_arrivals"] = int(frame[LABEL].isna().sum())
manifest["arrival_derivation_sha256"] = digest(Path(__file__))
manifest["policy_preregistered"].update(
    threshold_selection="90th percentile of ALL 1660 validation arrival scores; labels not used",
    engines_per_simulated_day=83, daily_review_cap=8,
    capacity_fraction=8 / 83,
    unknown_outcome_policy="Score and consume quota normally; report selected unknowns separately, never as negatives",
)
manifest["simulation_limits"][-1] = "The streaming quota assumes 83 daily arrivals and 8 daily extra-review slots."
(BASE / "dataset-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print("Operational replay includes 60 unknown-outcome arrivals per split; quota 8 / 83 per day.")
